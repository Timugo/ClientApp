# TimugoApp
Timugo app, build using flutter framework from google
